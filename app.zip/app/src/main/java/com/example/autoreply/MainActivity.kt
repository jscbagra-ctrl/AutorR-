package com.example.autoreply

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.File

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private var recorder: MediaRecorder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        askPermissions()

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val sw = Switch(this).apply {
            text = "ऑटो-रिप्लाई चालू"
            isChecked = prefs.getBoolean("on", false)
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("on", on).apply()
                val i = Intent(this@MainActivity, AutoReplyService::class.java)
                if (on) startForegroundService(i) else stopService(i)
            }
        }

        val delayLabel = TextView(this)
        val seek = SeekBar(this).apply {
            max = 15
            progress = prefs.getInt("delay", 3)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    prefs.edit().putInt("delay", p).apply()
                    delayLabel.text = "कॉल उठाने से पहले देरी: $p सेकंड"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        delayLabel.text = "कॉल उठाने से पहले देरी: ${seek.progress} सेकंड"

        val rg = RadioGroup(this)
        val rbTts = RadioButton(this).apply { text = "टेक्स्ट बोलकर सुनाओ"; id = 1 }
        val rbRec = RadioButton(this).apply { text = "मेरी रिकॉर्डिंग चलाओ"; id = 2 }
        rg.addView(rbTts); rg.addView(rbRec)
        rg.check(if (prefs.getString("mode", "tts") == "tts") 1 else 2)
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putString("mode", if (id == 1) "tts" else "rec").apply()
        }

        val msg = EditText(this).apply {
            hint = "यहाँ मैसेज लिखें"
            setText(prefs.getString("text", "नमस्ते, मैं अभी व्यस्त हूँ। कृपया बाद में कॉल करें।"))
        }

        val save = Button(this).apply {
            text = "मैसेज सेव करें"
            setOnClickListener {
                prefs.edit().putString("text", msg.text.toString()).apply()
                Toast.makeText(this@MainActivity, "सेव हो गया", Toast.LENGTH_SHORT).show()
            }
        }

        val rec = Button(this).apply {
            text = "रिकॉर्डिंग शुरू करें"
            setOnClickListener {
                if (recorder == null) {
                    startRecording(); text = "रिकॉर्डिंग रोकें"
                } else {
                    stopRecording(); text = "रिकॉर्डिंग शुरू करें"
                    Toast.makeText(this@MainActivity, "रिकॉर्डिंग सेव हुई", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val note = TextView(this).apply {
            text = "ध्यान दें: आवाज़ स्पीकर से माइक में जाती है, इसलिए कुछ फ़ोन में कमज़ोर हो सकती है। पहले किसी दूसरे फ़ोन से टेस्ट करें।"
            gravity = Gravity.START
        }

        listOf(sw, delayLabel, seek, rg, msg, save, rec, note).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    private fun startRecording() {
        recorder = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(File(filesDir, "reply.m4a").absolutePath)
            prepare(); start()
        }
    }

    private fun stopRecording() {
        recorder?.apply { stop(); release() }
        recorder = null
    }
}
