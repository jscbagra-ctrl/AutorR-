package com.example.autoreply

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import java.io.File
import java.util.Locale

class AutoReplyService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var player: MediaPlayer? = null
    private var scheduled = false
    private var answered = false
    private lateinit var prefs: SharedPreferences
    private lateinit var am: AudioManager

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> if (!scheduled && !answered) {
                    scheduled = true
                    handler.postDelayed({ answerCall() }, prefs.getInt("delay", 3) * 1000L)
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> if (answered) {
                    handler.postDelayed({ playReply() }, 800)
                }
                TelephonyManager.EXTRA_STATE_IDLE -> reset()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        am = getSystemService(AUDIO_SERVICE) as AudioManager

        val chId = "autoreply"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Auto Call Reply", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, chId)
            .setContentTitle("ऑटो-रिप्लाई चालू है")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setAudioAttributes(voiceAttrs())
            }
        }
        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, filter)
    }

    private fun voiceAttrs() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private fun answerCall() {
        if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) return
        answered = true
        (getSystemService(TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
    }

    @Suppress("DEPRECATION")
    private fun playReply() {
        am.isSpeakerphoneOn = true
        am.setStreamVolume(
            AudioManager.STREAM_VOICE_CALL,
            am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0
        )
        if (prefs.getString("mode", "tts") == "tts") {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { handler.post { endCall() } }
                override fun onDone(id: String?) { handler.postDelayed({ endCall() }, 500) }
            })
            tts?.speak(prefs.getString("text", "") ?: "", TextToSpeech.QUEUE_FLUSH, null, "reply")
        } else {
            val f = File(filesDir, "reply.m4a")
            if (!f.exists()) { endCall(); return }
            player = MediaPlayer().apply {
                setAudioAttributes(voiceAttrs())
                setDataSource(f.absolutePath)
                prepare()
                setOnCompletionListener { handler.postDelayed({ endCall() }, 500) }
                start()
            }
        }
    }

    private fun endCall() {
        if (Build.VERSION.SDK_INT >= 28 &&
            checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)
            == PackageManager.PERMISSION_GRANTED
        ) (getSystemService(TELECOM_SERVICE) as TelecomManager).endCall()
    }

    @Suppress("DEPRECATION")
    private fun reset() {
        handler.removeCallbacksAndMessages(null)
        tts?.stop()
        player?.release(); player = null
        am.isSpeakerphoneOn = false
        scheduled = false
        answered = false
    }

    override fun onDestroy() {
        reset()
        unregisterReceiver(receiver)
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
